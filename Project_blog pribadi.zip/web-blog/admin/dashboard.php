
<?php 
session_start();
if(!isset($_SESSION['login']) )
{
    header("Location:../404.html");
    exit;
}
include '../koneksi.php';
$email = $_SESSION['email'];

$query = "SELECT * FROM user WHERE email = '$email' ";
$result = mysqli_query($koneksi,$query);
$row = mysqli_fetch_assoc($result);
require '../asset/headeradmin.php';
require '../asset/sidebaradmin.php';
require '../asset/topbar.php';

; ?>


       

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                       
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="card mb-3" style="max-width: 540px;">
                            <div class="row no-gutters">
                                <div class="col-md-4 justify-content-center align-items-center">
                                    <img class="ml-2 mr-5" src="../img/avatar.svg" alt="..." width="180">
                                </div>
                                <div class="col-md-12">
                                <div class="card-body">
                                    <h5 class="card-title"><?= $row['nama'] ?>
                                    </h5>
                                    <p class="card-text"><?= $row['deskripsi'] ?></p>
                                    <p class="card-text"><small class="text-muted"><?= $row['email'] ?></small></p>
                                    <a class="btn btn-success" href="../admin/editbiodata.php?id=<?= $row['id_user'] ; ?>" role="button">Edit</a>
                                </div>
                                </div>
                            </div>
                        </div>

                       
                    </div>

                 
                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            
<?php 

require '../asset/footeradmin.php';
; ?>