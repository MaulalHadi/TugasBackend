<?php 
session_start();
if(!isset($_SESSION['login']) )
{
    header("Location:../404.html");
    exit;
}
require '../asset/headeradmin.php';
require '../asset/sidebaradmin.php';
require '../asset/topbar.php';
require '../koneksi.php';
require '../functions.php';

$id = $_GET['id'];
$query = "SELECT * FROM user WHERE id_user = '$id'";
$result = mysqli_query($koneksi,$query);
if(isset($_POST['submit']))
{
    if(edituser($_POST))
    {
        echo "
        <script>alert('Data Berhasil Diedit');window.location.href = '../admin/dashboard.php';</script>
        ";
    }
}


 ?>


       

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Edit Biodata</h1>
    <!-- Content Row -->
    <?php while($row = mysqli_fetch_assoc($result)): ?>
        <form  action="" method="post" enctype="multipart/form-data">
            <div class="row">
            
                        <div class="col-md-6">
                            <input type="hidden" name="id" value="<?= $row['id_user'] ; ?>">
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Deskripsi Diri</label>
                                <textarea name="deskripsi" class="form-control" id="exampleFormControlTextarea1" rows="3"  required><?= $row['deskripsi'] ; ?></textarea>
                            </div>
                        <button type="submit" name="submit" class="btn btn-primary">Edit</button>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama</label>
                                <input type="text" name="nama" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?= $row['nama'] ; ?>" required>
                            </div>
                        </div>
                             
                        
                    </div>
          
        </form>  
    <?php endwhile ; ?>
    
                 
                    

</div>
<!-- /.container-fluid -->
</div>


<?php require '../asset/footeradmin.php';?>
