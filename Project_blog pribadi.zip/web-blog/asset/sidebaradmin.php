<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
    <div class="sidebar-brand-icon rotate-n-15">
        <i class="fas fa-blog"></i>
    </div>
    <div class="sidebar-brand-text mx-3">blog</div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<?php if($_SESSION['status'] == '2') { ?>
    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="../blogger/blogger.php">
            <i class="fas fa-fw fa-list"></i>
            <span>Blog</span></a>
    </li>
<?php } 
else if($_SESSION['status'] == '1') {?>
    <li class="nav-item">
        <a class="nav-link" href="../petugas/petugas.php">
            <i class="fas fa-fw fa-users"></i>
            <span>Data Admin</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../kategori/kategori.php">
            <i class="fas fa-fw fa-list"></i>
            <span>Data Kategori</span></a>
    </li>
<?php }?>
    




<!-- Divider -->
<hr class="sidebar-divider">
 
</ul>
<!-- End of Sidebar -->