
<?php 
session_start();
if(!isset($_SESSION['login']) ||  $_SESSION['status'] != '2')
{
    header("Location:../404.html");
    exit;
}
require '../asset/headeradmin.php';
require '../asset/sidebaradmin.php';
require '../asset/topbar.php';
require '../koneksi.php';
require '../functions.php';

$id = $_GET['id'];
$query = "SELECT * FROM blog WHERE id_blog = '$id'";
$result = mysqli_query($koneksi,$query);

$query2 = "SELECT * FROM kategori ";
$result2 = mysqli_query($koneksi,$query2);
if(isset($_POST['submit']))
{
    if(editblog($_POST))
    {
        echo "
        <script>alert('Data Berhasil Diedit');window.location.href = '../blogger/blogger.php';</script>
        ";
    }
}

 ?>


       

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Edit Blog</h1>
    <!-- Content Row -->
    <?php while($row = mysqli_fetch_assoc($result)): ?>
        <form  action="" method="post" enctype="multipart/form-data">
            <div class="row">
            
                    <div class="col-md-6">
                        <label for="exampleFormControlTextarea1">Gambar Laptop</label>
                        <input type="hidden" name="id" value="<?= $row['id_blog'] ; ?>">
                        <input type="hidden" name="gambarlama" value="<?= $row['gambar'] ; ?>">
                        <div class="custom-file">
                            <input type="file" name="gambar" class="custom-file-input" id="inputGroupFile02" >
                            <label class="custom-file-label" for="customFile" >Choose file</label>
                        </div>
                        <img width="100" src="../img/blog/<?= $row['gambar'] ; ?>" alt="">

                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Pembahasan</label>
                            <textarea name="pembahasan" class="form-control" id="exampleFormControlTextarea1"  rows="3"><?= $row['pembahasan'] ; ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Judul Blog</label>
                        <input type="text" name="judul" class="form-control" id="exampleInputEmail1" value="<?= $row['judul'] ; ?>" aria-describedby="emailHelp">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Kategori</label>
                        <select name="kategori" class="form-control" id="exampleFormControlSelect1" required>
                            <option value="">Pilih Jenis Kategori</option>
                            <?php while($row2 = mysqli_fetch_assoc($result2)): ?>
                                <option value="<?= $row2['id_kategori'] ; ?>"><?= $row2['nama_kategori'] ; ?>
                                </option>
                            <?php endwhile ; ?>
                        </select>
                    </div>
                        <button type="submit" name="submit" class="btn btn-primary">Edit</button>
                        
                    </div>
            </div>  
        </form>  
    <?php endwhile ; ?>
    
                 
                    

</div>
<!-- /.container-fluid -->
</div>

<script type="text/javascript">

    $('.custom-file input').change(function (e) {
        var files = [];
        for (var i = 0; i < $(this)[0].files.length; i++) {
            files.push($(this)[0].files[i].name);
        }
        $(this).next('.custom-file-label').html(files.join(', '));
    });

</script>      
<?php 

require '../asset/footeradmin.php';?>