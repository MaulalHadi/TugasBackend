

<?php 

$koneksi = mysqli_connect("localhost","root","","jual_laptop");

if (!$koneksi)
 {
	echo"nana";
}
 ?>